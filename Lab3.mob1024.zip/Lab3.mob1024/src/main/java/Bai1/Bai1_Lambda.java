/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai1;

/**
 *
 * @author Bao Khoa
 */


import java.util.ArrayList;
import java.util.Collections;

public class Bai1_Lambda {
    public static void main(String[] args) {

        // Tạo danh sách
        ArrayList<String> dsTen = new ArrayList<>();
        dsTen.add("Nguyen");
        dsTen.add("Khoa");
        dsTen.add("AnhTuan");
        dsTen.add("Minh");
        dsTen.add("Phuong");
        dsTen.add("HoangNam");
        dsTen.add("Lan");
        dsTen.add("Thanh");
        dsTen.add("QuangHuy");
        dsTen.add("Bao");

        // 1. In danh sách
        System.out.println("Danh sach:");
        dsTen.forEach(ten -> System.out.println(ten));

        // 2. Lọc tên > 5 ký tự
        System.out.println("\nTen > 5 ky tu:");
        dsTen.stream()
                .filter(ten -> ten.length() > 5)
                .forEach(ten -> System.out.println(ten));

        // 3. Sắp xếp A-Z
        System.out.println("\nSap xep A-Z:");
        Collections.sort(dsTen, (a, b) -> a.compareTo(b));
        dsTen.forEach(ten -> System.out.println(ten));

        // 4. Sắp xếp theo độ dài
        System.out.println("\nSap xep theo do dai:");
        Collections.sort(dsTen, (a, b) -> a.length() - b.length());
        dsTen.forEach(ten -> System.out.println(ten));
    }
}

