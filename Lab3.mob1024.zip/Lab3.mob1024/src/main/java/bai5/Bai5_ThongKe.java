/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai5;

/**
 *
 * @author Bao Khoa
 */


import bai4.Student;
import bai4.StudentType;
import java.util.*;
import java.util.stream.Collectors;

public class Bai5_ThongKe {
    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();

        list.add(new Student("S01", "An", StudentType.INTERNATIONAL, 3.5));
        list.add(new Student("S02", "Binh", StudentType.REGULAR, 2.8));
        list.add(new Student("S03", "Cuong", StudentType.PART_TIME, 3.0));
        list.add(new Student("S04", "Dung", StudentType.INTERNATIONAL, 3.3));
        list.add(new Student("S05", "Anh", StudentType.PART_TIME, 3.6));
        list.add(new Student("S06", "Huy", StudentType.REGULAR, 2.5));
        list.add(new Student("S07", "Lan", StudentType.INTERNATIONAL, 3.1));
        list.add(new Student("S08", "Phuong", StudentType.PART_TIME, 3.4));
        list.add(new Student("S09", "Quang", StudentType.REGULAR, 3.7));
        list.add(new Student("S10", "AnKhoa", StudentType.INTERNATIONAL, 3.8));

        // 1. Đếm số SV theo từng loại
        Map<StudentType, Long> countMap = list.stream()
                .collect(Collectors.groupingBy(
                        Student::getType,
                        Collectors.counting()
                ));

        System.out.println("So luong theo tung loai:");
        countMap.forEach((type, count) ->
                System.out.println(type + ": " + count)
        );

        // 2. GPA trung bình theo từng loại
        Map<StudentType, Double> avgMap = list.stream()
                .collect(Collectors.groupingBy(
                        Student::getType,
                        Collectors.averagingDouble(Student::getGpa)
                ));

        System.out.println("\nGPA trung binh theo tung loai:");
        avgMap.forEach((type, avg) ->
                System.out.println(type + ": " + avg)
        );

        // 3. Loại có GPA TB cao nhất
        Optional<Map.Entry<StudentType, Double>> max = avgMap.entrySet()
                .stream()
                .max(Map.Entry.comparingByValue());

        System.out.println("\nLoai co GPA trung binh cao nhat:");
        max.ifPresent(e ->
                System.out.println(e.getKey() + " - " + e.getValue())
        );
    }
}
