/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai4;

/**
 *
 * @author Bao Khoa
 */

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Bai4_Stream {
    public static void main(String[] args) {

        List<Student> list = new ArrayList<>();

        list.add(new Student("S01", "An", StudentType.INTERNATIONAL, 3.5));
        list.add(new Student("S02", "Binh", StudentType.REGULAR, 2.8));
        list.add(new Student("S03", "Cuong", StudentType.PART_TIME, 3.0));
        list.add(new Student("S04", "Dung", StudentType.INTERNATIONAL, 3.3));
        list.add(new Student("S05", "Anh", StudentType.PART_TIME, 3.6));
        list.add(new Student("S06", "Huy", StudentType.REGULAR, 2.5));
        list.add(new Student("S07", "Lan", StudentType.INTERNATIONAL, 3.1));
        list.add(new Student("S08", "Phuong", StudentType.PART_TIME, 3.4));
        list.add(new Student("S09", "Quang", StudentType.REGULAR, 3.7));
        list.add(new Student("S10", "AnKhoa", StudentType.INTERNATIONAL, 3.8));

        // 1. Lọc INTERNATIONAL có GPA >= 3.2
        System.out.println("INTERNATIONAL >= 3.2:");
        list.stream()
                .filter(s -> s.getType() == StudentType.INTERNATIONAL && s.getGpa() >= 3.2)
                .forEach(System.out::println);

        // 2. Top 3 GPA cao nhất
        System.out.println("\nTop 3 GPA cao nhat:");
        list.stream()
                .sorted((a, b) -> Double.compare(b.getGpa(), a.getGpa()))
                .limit(3)
                .forEach(System.out::println);

        // 3. Danh sách tên PART_TIME
        System.out.println("\nTen sinh vien PART_TIME:");
        List<String> names = list.stream()
                .filter(s -> s.getType() == StudentType.PART_TIME)
                .map(Student::getName)
                .collect(Collectors.toList());

        names.forEach(System.out::println);
    }
}