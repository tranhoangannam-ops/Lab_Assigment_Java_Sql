/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bai2;

/**
 *
 * @author Bao Khoa
 */


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class stream {
    public static void main(String[] args) {

        List<Employee> list = new ArrayList<>();

        list.add(new Employee("E01", "Anh", 16000000));
        list.add(new Employee("E02", "Binh", 12000000));
        list.add(new Employee("E03", "An", 18000000));
        list.add(new Employee("E04", "Cuong", 14000000));
        list.add(new Employee("E05", "Dung", 20000000));
        list.add(new Employee("E06", "AnKhoa", 15500000));
        list.add(new Employee("E07", "Huy", 10000000));
        list.add(new Employee("E08", "AnPhat", 17000000));

        // 1. Lọc
        System.out.println("Luong >= 15tr:");
        list.stream()
                .filter(e -> e.getSalary() >= 15000000)
                .forEach(System.out::println);

        // 2. Sắp xếp giảm dần
        System.out.println("\nLuong giam dan:");
        list.stream()
                .sorted((a, b) -> Double.compare(b.getSalary(), a.getSalary()))
                .forEach(System.out::println);

        // 3. Map -> lấy tên
        System.out.println("\nDanh sach ten:");
        List<String> names = list.stream()
                .map(Employee::getName)
                .collect(Collectors.toList());

        names.forEach(System.out::println);

        // 4. Count
        long count = list.stream()
                .filter(e -> e.getName().toLowerCase().startsWith("a"))
                .count();

        System.out.println("\nSo ten bat dau bang A: " + count);
    }
}
