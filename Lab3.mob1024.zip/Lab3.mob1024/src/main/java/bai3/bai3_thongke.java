/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bai3;

/**
 *
 * @author Bao Khoa
 */

import Bai2.Employee;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

public class bai3_thongke {
    public static void main(String[] args) {

        List<Employee> list = new ArrayList<>();

        list.add(new Employee("E01", "Anh", 16000000));
        list.add(new Employee("E02", "Binh", 12000000));
        list.add(new Employee("E03", "An", 18000000));
        list.add(new Employee("E04", "Cuong", 14000000));
        list.add(new Employee("E05", "Dung", 20000000));
        list.add(new Employee("E06", "AnKhoa", 15500000));
        list.add(new Employee("E07", "Huy", 10000000));
        list.add(new Employee("E08", "AnPhat", 17000000));

        // 1. Tổng lương
        double tongLuong = list.stream()
                .mapToDouble(e -> e.getSalary())
                .sum();

        // 2. Lương trung bình
        double trungBinh = list.stream()
                .mapToDouble(e -> e.getSalary())
                .average()
                .orElse(0);

        // 3. Nhân viên lương cao nhất
        Optional<Employee> maxLuong = list.stream()
                .max(Comparator.comparingDouble(e -> e.getSalary()));

        // ===== IN KẾT QUẢ =====
        System.out.println("===== THONG KE =====");

        System.out.println("Tong luong: " + tongLuong);

        System.out.println("Luong trung binh: " + trungBinh);

        System.out.println("Nhan vien luong cao nhat:");
        maxLuong.ifPresent(e -> System.out.println(e));
    }
}