/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import exception.DuplicateEmployeeException;
import exception.InvalidSalaryException;
import java.util.ArrayList;
import model.Employee;

/**
 *
 * @author MinhTu
 */
public class EmployeeService {
    private ArrayList<Employee> list = new ArrayList<>();

    public void add(Employee e) throws DuplicateEmployeeException, InvalidSalaryException {

        if (e.getSalary() < 0) {
            throw new InvalidSalaryException("Lương không hợp lệ!");
        }

        for (Employee emp : list) {
            if (emp.getId().equals(e.getId())) {
                throw new DuplicateEmployeeException("Trùng ID!");
            }
        }

        list.add(e);
    }

    public Employee find(String id) {
        for (Employee e : list) {
            if (e.getId().equals(id)) return e;
        }
        return null;
    }

    public ArrayList<Employee> getAll() {
        return list;
    }
}
