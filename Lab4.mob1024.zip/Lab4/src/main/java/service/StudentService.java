/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;
import java.util.ArrayList;
import model.Student;

/**
 *
 * @author MinhTu
 */
public class StudentService {
    private ArrayList<Student> list = new ArrayList<>();

    public void add(Student s) {
        if (s.getId().isEmpty() || s.getName().isEmpty()) {
            throw new IllegalArgumentException("ID hoặc Name không được rỗng!");
        }

        if (s.getGpa() < 0 || s.getGpa() > 4) {
            throw new IllegalArgumentException("GPA phải từ 0-4!");
        }

        list.add(s);
    }

    public ArrayList<Student> getAll() {
        return list;
    }
}
