/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import exception.EmptyListException;
import java.util.ArrayList;

/**
 *
 * @author MinhTu
 */
public class GenericManager<T> {
    private ArrayList<T> list = new ArrayList<>();

    public void add(T obj) {
        list.add(obj);
    }

    public void display() {
        for (T obj : list) {
            System.out.println(obj);
        }
    }

    public int size() {
        return list.size();
    }

    public T getFirst() throws EmptyListException {
        if (list.isEmpty()) {
            throw new EmptyListException("Danh sách rỗng!");
        }
        return list.get(0);
    }

    public T getLast() throws EmptyListException {
        if (list.isEmpty()) {
            throw new EmptyListException("Danh sách rỗng!");
        }
        return list.get(list.size() - 1);
    }
}
