/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import java.util.Scanner;
import model.Employee;
import service.EmployeeService;

/**
 *
 * @author MinhTu
 */
public class EmployeeView {
    private EmployeeService service = new EmployeeService();
    private Scanner sc = new Scanner(System.in);

    public void menu() {
        while (true) {
            System.out.println("1. Thêm | 2. Tìm | 3. Hiển thị | 0. Thoát");
            int options = Integer.parseInt(sc.nextLine());

            try {
                switch (options) {
                    case 1:
                        System.out.print("ID: ");
                        String id = sc.nextLine();
                        System.out.print("Name: ");
                        String name = sc.nextLine();
                        System.out.print("Salary: ");
                        double salary = Double.parseDouble(sc.nextLine());

                        service.add(new Employee(id, name, salary));
                        break;

                    case 2:
                        System.out.print("Nhập ID: ");
                        Employee e = service.find(sc.nextLine());
                        System.out.println(e == null ? "Không tìm thấy" : e);
                        break;

                    case 3:
                        for (Employee emp : service.getAll()) {
                            System.out.println(emp);
                        }
                        break;

                    case 0:
                        return;
                }
            } catch (Exception e) {
                System.out.println("Lỗi: " + e.getMessage());
            }
        }
    }
}
