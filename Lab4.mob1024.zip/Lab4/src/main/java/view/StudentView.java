/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;
import java.util.Scanner;
import model.Student;
import service.StudentService;

/**
 *
 * @author MinhTu
 */
public class StudentView {
    private StudentService service = new StudentService();
    private Scanner sc = new Scanner(System.in);

    public void menu() {
        while (true) {
            System.out.println("1. Thêm SV | 2. Hiển thị | 0. Thoát");
            int options = Integer.parseInt(sc.nextLine());

            try {
                switch (options) {
                    case 1:
                        System.out.print("ID: ");
                        String id = sc.nextLine();
                        System.out.print("Name: ");
                        String name = sc.nextLine();
                        System.out.print("GPA: ");
                        double gpa = Double.parseDouble(sc.nextLine());

                        service.add(new Student(id, name, gpa));
                        break;

                    case 2:
                        for (Student s : service.getAll()) {
                            System.out.println(s);
                        }
                        break;

                    case 0:
                        return;
                }
            } catch (Exception e) {
                System.out.println("Lỗi: " + e.getMessage());
            }
        }
    }
}
