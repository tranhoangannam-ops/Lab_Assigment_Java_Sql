/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;
import java.util.Scanner;
import view.EmployeeView;
import view.StudentView;

/**
 *
 * @author MinhTu
 */
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("===== MENU =====");
            System.out.println("1. Student");
            System.out.println("2. Employee");
            System.out.println("0. Thoát");

            int choice = Integer.parseInt(sc.nextLine());

            switch (choice) {
                case 1:
                    new StudentView().menu();
                    break;
                case 2:
                    new EmployeeView().menu();
                    break;
                case 0:
                    return;
            }
        }
    }
}
