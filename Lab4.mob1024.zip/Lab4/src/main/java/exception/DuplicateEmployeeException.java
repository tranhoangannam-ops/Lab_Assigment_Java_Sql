/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exception;

/**
 *
 * @author MinhTu
 */
public class DuplicateEmployeeException extends Exception {
    public DuplicateEmployeeException(String msg) {
        super(msg);
    }
}
